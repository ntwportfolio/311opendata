    /////////// Create layer renderers ///////////////////////////////////////////////////////////////////
const fundingRenderer = {
    type: 'simple',
    symbol: {
        color: "#008FBF",
        type: 'simple-line',
        style: 'solid',
        width: 1
    },

};

const facFundingRenderer = {
    type: 'simple',
    symbol: {
        color: "#DCBA8B",
        type: 'simple-fill',
        outline: {
            width: 0.5,
            color: '#072227'

        }
    }
};

const facilitiesFundingRenderer = {
    type: 'simple',
    symbol: {
        color: '#9C5085',
        type: 'simple-fill',
        outline: {
            width: 0.5,
            color: '#9C5085'

        }
    },
  
  };

const ferriesRenderer = {
  type: 'simple',
  symbol: {
      color: "#4D6AFF",
      type: 'simple-marker',
      style: 'square',
      size: 7,
      outline: {
          width: 1.5,
          color: "#4D6AFF"
      }
  },
};

const bridgeRenderer = {
    type: 'simple',
    symbol: {
        color: '#B49900',
        type: 'simple-marker',
        style: 'circle',
        size: 8,
        outline: {
        width: 0.5,
        color: '#072227'

        }
    },
};

const rampRenderer = {
    type: 'simple',
    symbol: {
        color: "#35858B",
        type: 'simple-marker',
        style: 'circle',
        size: 7,
        outline: {
            width: 0.5,
            color: "#072227"

        }
    }

};

const resurfacingRenderer = {
    type: 'simple',
    symbol: {
        color: "#6F8D38",
        type: 'simple-line',
        style: 'solid',
        width: 1
    },

};


///////////////////////////////////////// Add feature Layers ///////////////////////////////////////////////

const fundStatusColor = (feature) => {
  const statusFund = feature.graphic && feature.graphic.attributes.FundStatus
  const lyRenderer = feature.graphic.layer.renderer 
  let colorFund = ""

  if(lyRenderer.defaultSymbol != null) {
    colorFund = lyRenderer.defaultSymbol["color"]
  }

  for (let index = 0; index < lyRenderer.uniqueValueInfos.length; index++) {
      const currentValue = lyRenderer.uniqueValueInfos[index].value;
      if (currentValue == statusFund) {
          color = lyRenderer.uniqueValueInfos[index].symbol["color"];
          if(color) {
              colorFund = color
          }
      }
  }
//   console.log('color0', colorFund)
  return(colorFund);
}

const costExpression = {
  name: "Cost",
  title: "Cost",
  expression: "Text($feature.Cost, '$ ###,###,###')"
};

const streetsObj = {
    id: 'streets',
    title: 'Street Reconstruction',
    url: 'https://gis.nycdot.nyc/arcgis/rest/services/APM/Street_Reconstruction_Projects/MapServer/0',
    renderer: fundingRenderer,
    //definitionExpression: "ProjStatus <> 'Completed Project' AND ProjStatus <> 'Canceled'",
    visible: true,
    labelsVisible: false,
    labelingInfo: {
        id: 'FMSID',
        projDesc: 'PROJ_ID_DESC'
    },
    popupTemplate: {
        title: `
            <h4>{FMSID}<h4/>
            <h2>{PROJ_ID_DESC}</h2>
            <h4>
            {ProjStatus}
            <h4/>
            <hr>
        `,
        // content: (feature) => {
        //     const colorFund = fundStatusColor(feature)
        //     const status = feature.graphic && feature.graphic.attributes.FundStatus
        //     const content = `
        //         <br/>
        //         <h2><span style="font-weight: lighter;">Division: </span> {Division}</h2>
        //         <br/>
        //         <h2 style="color: ` + colorFund + `"><span style="font-weight: lighter;color:black;">Funding Status: </span>${status == null ? "Not Specified" : "{FundStatus}"}</h2>            
        //         <br/>
        //         <h2><span style="font-weight: lighter;">Commitment Status: </span>{Planned_Or_Committed}</h2>
        //         <br/>
        //         <h2><span style="font-weight: lighter;">Construction FY: </span> {FYCons}</h2>
        //         <br/>
        //         <h2><span style="font-weight: lighter;">Cost: </span> {expression/Cost}</h2>
        //     `
        //     return (content)
        // },
        content: `
            <br/>
            <h2><span style="font-weight: lighter;">Division: </span> {Division}</h2>
            <br/>
            <h2><span style="font-weight: lighter;">Commitment Status: </span>{Planned_Or_Committed}</h2>
            <br/>
            <h2><span style="font-weight: lighter;">Construction FY: </span> {FYCons}</h2>
            <br/>
            <h2><span style="font-weight: lighter;">Cost: </span> {expression/Cost}</h2>
        `,
        outFields: ["*"],
        expressionInfos: [costExpression]
    }
};
  
const bridgesObj = {
    id: 'bridges',
    title: 'Bridges',
    url: 'https://gis.nycdot.nyc/arcgis/rest/services/APM/Bridge_Projects/MapServer/0',
    renderer: bridgeRenderer,
    //definitionExpression: "ProjStatus <> 'Completed' AND ProjStatus <> 'N/A, Completed' AND ProjStatus <> 'Cancelled'",
    visible: false,
    labelsVisible: false,
    labelingInfo: {
        id: 'FMSID',
        projDesc: 'PROJ_ID_DE'
    },
    popupTemplate: {
        title: `
            <h4>{FMSID}<h4/>
            <h2>{PROJ_ID_DE}</h2>
            <h4>
            {ProjStatus}
            <h4/>
            <hr>
        `,
        // content: (feature) => {
        //     const colorFund = fundStatusColor(feature)
        //     const status = feature.graphic && feature.graphic.attributes.FundStatus
        //     console.log('status', status)
        //     const content = `
        //         <br/>
        //         <h2><span style="font-weight: lighter;">Division: </span>{Division}</h2>
        //         <br/>
        //         <h2 style="color: ` + colorFund + `"><span style="font-weight: lighter; color:black;">Funding Status: </span> ${status == null ? "Not Specified" : "{FundStatus}"}</h2>
        //         <br/>
        //         <h2><span style="font-weight: lighter;">Commitment Status: </span>{Planned_Or_Committed}</h2>
        //         <br/>
        //         <h2><span style="font-weight: lighter;">Construction FY: </span>{FYCons}</h2>
        //         <br/>
        //         <h2><span style="font-weight: lighter;">Cost: </span>{expression/Cost}</h2>
                
        //     `
        //     return (content)
        // },
        content: `
            <br/>
            <h2><span style="font-weight: lighter;">Division: </span>{Division}</h2>
            <br/>
            <h2><span style="font-weight: lighter;">Commitment Status: </span>{Planned_Or_Committed}</h2>
            <br/>
            <h2><span style="font-weight: lighter;">Construction FY: </span>{FYCons}</h2>
            <br/>
            <h2><span style="font-weight: lighter;">Cost: </span>{expression/Cost}</h2>
            
        `,
        outFields: ["*"],
        expressionInfos: [costExpression]
    }
};
  
const ferriesObj = {
    id: 'ferries',
    title: 'Ferries',
    url: 'https://gis.nycdot.nyc/arcgis/rest/services/APM/Ferries_Projects/MapServer/0',
    renderer: ferriesRenderer,
    //definitionExpression: "ProjStatus <> 'Completed' AND ProjStatus <> 'Cancelled'",
    visible: false,
    labelsVisible: false,
    labelingInfo: {
        id: 'FMSID',
        projDesc: 'PROJ_ID_DE'
    },
    popupTemplate: {
        title: `
        <h4>{FMSID}<h4/>
        <h2>{PROJ_ID_DE}</h2>
        <h4>
        {ProjStatus}
        <h4/>
        <hr>
    `,
    // content: (feature) => {
    //     const colorFund = fundStatusColor(feature)
    //     const status = feature.graphic && feature.graphic.attributes.FundStatus
    //     const content = `
    //         <br/>
    //         <h2><span style="font-weight: lighter;">Division: </span>{Division}</h2>
    //         <br/>
    //         <h2 style="color: ` + colorFund + `"><span style="font-weight: lighter; color:black;">Funding Status: </span> ${status == null ? "Not Specified" : "{FundStatus}"} </h2>            
    //         <br/>
    //         <h2><span style="font-weight: lighter;">Commitment Status: </span>{Planned_Or_Committed}</h2>
    //         <br/>
    //         <h2><span style="font-weight: lighter;">Construction FY: </span>{FYCons}</h2>
    //         <br/>
    //         <h2><span style="font-weight: lighter;">Cost: </span>{expression/Cost}</h2>
    //     `
    //     return (content)
    // },
    content: `
        <br/>
        <h2><span style="font-weight: lighter;">Division: </span>{Division}</h2>
        <br/>
        <h2><span style="font-weight: lighter;">Commitment Status: </span>{Planned_Or_Committed}</h2>
        <br/>
        <h2><span style="font-weight: lighter;">Construction FY: </span>{FYCons}</h2>
        <br/>
        <h2><span style="font-weight: lighter;">Cost: </span>{expression/Cost}</h2>
    `,
    outFields: ["*"],
    expressionInfos: [costExpression]
    }
};
  
const resurfacingObj = {
    id: 'resurfacing',
    title: 'Resurfacing',
    url: 'https://gis.nycdot.nyc/arcgis/rest/services/APM/Resurfacing_Projects/MapServer/0',
    renderer: resurfacingRenderer,
    //definitionExpression: "ProjStatus <> 'Completed' AND ProjStatus <> 'Cancelled'",
  
    visible: false,
    labelsVisible: false,
    labelingInfo: {
        id: 'CapitalProjectID',
        projDesc: 'Division'
    },
    popupTemplate: {
        title: `
            <h4>{CapitalProjectID}<h4/>
            <h2>{Division}</h2>
            <hr>
        `,
        content: `
            <br/>
            <h2><span style="font-weight: lighter;">Fiscal Year: </span>{FY}</h2>
            <br/>
            <h2><span style="font-weight: lighter;">Neighborhood Tabulation Area: </span>{NTAName}</h2>
            <br/>
            <h2><span style="font-weight: lighter;">Actual Date Completion: </span>{ActualEndDate}</h2>
            <br/>
            <h2><span style="font-weight: lighter;">Cost: </span>{expression/Cost}</h2>
        `,
        outFields: ["*"],
        expressionInfos: [costExpression]
    }
};
  
const pedRampsObj = {
    id: 'pedRamps',
    title: 'Pedestrian Ramps',
    url: 'https://gis.nycdot.nyc/arcgis/rest/services/APM/Sidewalks_Ped_Ramp_Projects/MapServer/0',
    renderer: rampRenderer,
    //definitionExpression: "ProjStatus <> 'Completed' AND ProjStatus <> 'Cancelled'",
  
    visible: false,
    labelsVisible: false,
    labelingInfo: {
        id: 'FMSID',
        projDesc: 'PROJ_ID_DE'
    },
    popupTemplate: {
        title: `
            <h4>{FMSID}<h4/>
            <h2>{PROJ_ID_DE}</h2>
            <hr>
        `,
        content: `
            <br/>
            <h2><span style="font-weight: lighter;">Division: </span>{Division}</h2>
            <br/>
            <h2><span style="font-weight: lighter;">Commitment Status: </span>{Planned_Or_Committed}</h2>
            <br/>
            <h2><span style="font-weight: lighter;">Construction FY: </span>{FYCons}</h2>
        `,
        outFields: ["*"],
        expressionInfos: [costExpression]
    }
};
  
const facilitiesObj = {
    id: 'facilities',
    title: 'Facilities',
    url: 'https://gis.nycdot.nyc/arcgis/rest/services/APM/Facilities_Project/MapServer/0',
    renderer: facilitiesFundingRenderer,
    //definitionExpression: "ProjStatus <> 'Completed' AND ProjStatus <> 'Cancelled'",
  
    visible: false,
    labelsVisible: false,
    labelingInfo: {
        id: 'FMSID',
        projDesc: 'PROJ_ID_DE'
    },
    popupTemplate: {
        title: `
            <h4>{FMSID}<h4/>
            <h2>{PROJ_ID_DE}</h2>
            <h4>
            {ProjStatus}
            <h4/>
            <hr>
        `,
        // content: (feature) => {
        //     const colorFund = fundStatusColor(feature)
        //     const status = feature.graphic && feature.graphic.attributes.FundStatus
        //     const content = `
        //         <br/>
        //         <h2><span style="font-weight: lighter;">Division: </span>{Division}</h2>
        //         <br/>
        //         <h2 style="color: ` + colorFund + `"><span style="font-weight: lighter; color:black;">Funding Status: </span>${status == null ? "Not Specified" : "{FundStatus}"}</h2>            
        //         <br/>
        //         <h2><span style="font-weight: lighter;">Commitment Status: </span>{Planned_Or_Committed}</h2>
        //         <br/>
        //         <h2><span style="font-weight: lighter;">Construction FY: </span>{FYCons}</h2>
        //         <br/>
        //         <h2><span style="font-weight: lighter;">Cost: </span>{expression/Cost}</h2>
        //     `
        //     return (content)
        // },
        content: `
            <br/>
            <h2><span style="font-weight: lighter;">Division: </span>{Division}</h2>           
            <br/>
            <h2><span style="font-weight: lighter;">Commitment Status: </span>{Planned_Or_Committed}</h2>
            <br/>
            <h2><span style="font-weight: lighter;">Construction FY: </span>{FYCons}</h2>
            <br/>
            <h2><span style="font-weight: lighter;">Cost: </span>{expression/Cost}</h2>
        `,
        outFields: ["*"],
        expressionInfos: [costExpression]
    }
};
  
const sidewalksObj = {
    id: 'sidewalks',
    title: 'Sidewalks Prior Notice',
    url: 'https://gis.nycdot.nyc/arcgis/rest/services/APM/Sidewalks_Prior_Notice_Projects/MapServer/0',
    renderer: facFundingRenderer,
    //definitionExpression: "ProjStatus <> 'Completed' AND ProjStatus <> 'Cancelled'",
    visible: false,
    labelsVisible: false,
    labelingInfo: {
        id: 'FMSID',
        projDesc: 'PROJ_ID_DE'
    },
    popupTemplate: {
        title: `
            <h4>{FMSID}<h4/>
            <h2>{PROJ_ID_DE}</h2>
            <h4>
            {ProjStatus}
            <h4/>
            <hr>
        `,
        // content: (feature) => {
        //     const colorFund = fundStatusColor(feature)
        //     const status = feature.graphic && feature.graphic.attributes.FundStatus
        //     const content = `
        //         <br/>
        //         <h2><span style="font-weight: lighter;">Division: </span>{Division}</h2>
        //         <br/>
        //         <h2 style="color: ` + colorFund + `"><span style="font-weight: lighter; color:black;">Funding Status: </span>${status == null ? "Not Specified" : "{FundStatus}"}</h2>            
        //         <br/>
        //         <h2><span style="font-weight: lighter;">Commitment Status: </span>{Planned_Or_Committed}</h2>
        //         <br/>
        //         <h2><span style="font-weight: lighter;">Construction FY: </span>{FYCons}</h2>
        //     `
        //     return (content)
        // },
        content: `
            <br/>
            <h2><span style="font-weight: lighter;">Division: </span>{Division}</h2>
            <br/>
            <h2><span style="font-weight: lighter;">Commitment Status: </span>{Planned_Or_Committed}</h2>
            <br/>
            <h2><span style="font-weight: lighter;">Construction FY: </span>{FYCons}</h2>
        `,
        outFields: ["*"],
        expressionInfos: [costExpression]
    }
};

/// city council districts
const cityCouncilRenderer = {
    type: "simple",
    symbol: {
        type: "simple-fill",
        color: null,
        outline: {
            color: "#e41a1c",
            width: 2
        }
    }
};
  
const cityCouncilDistrictsObj = {
    id: 'cityCouncilDistricts',
    title: 'City Council Districts',
    url: 'https://gis.nycdot.nyc/arcgis/rest/services/GAZETTEER/NYCDOTBasemapAdminBoundaries/MapServer/0',
    renderer: cityCouncilRenderer,
    visible: false,
    minScale: 0,
    labelsVisible: true,
    //editingEnabled: true,
    //capabilities: 'Create,Query,Update,Delete', // Ensure Create capability is allowed
    //outFields: ['*'],
    labelingInfo: [{
        labelExpressionInfo: {
            expression: "$feature.CounDist" // Set the field expression for the label
        },
        symbol: {
            type: "text",
            color: "black",
            font: {
                family: "Arial",
                size: 12,
                weight: "bold"
            },
            haloColor: "white",
            haloSize: 2,
        },
    }],
    popupTemplate: {
    title: `
        <h4>City Council District</h4>
        <h1>{CounDist}</h1>
        <hr>
    `,
    content: (feature) => {
        // Custom JavaScript logic to find the corresponding Member based on CounDist
        var noValue = feature.graphic.attributes.CounDist;
        var matchingApiItem = members["CouncilApiData"].find(item => item["district"] == noValue);
  
        // Return HTML content for the popup
        return `
            <h2><span style="font-weight: lighter;">Member: </span>${matchingApiItem ? matchingApiItem.name : 'Member not found'}</h2>
        `;
    },
    outFields: ["*"],
  
    }
  
};
  
// Community Districts
// community districts renderer
const communityDistrictsRenderer = {
type: "simple",
symbol: {
    type: "simple-fill",
    color: null,
    outline: {
        color: "#ff7f00",
        width: 2
    }
}
};
const communityDistrictsObj = {
    id: 'communityDistricts',
    title: 'Community Districts',
    url: 'https://gis.nycdot.nyc/arcgis/rest/services/GAZETTEER/NYCDOTBasemapAdminBoundaries/MapServer/1',
    renderer: communityDistrictsRenderer,
    visible: false,
    minScale: 0,
    labelsVisible: true,
    labelingInfo: [{
        labelExpressionInfo: {
            expression: "$feature.BoroCD" // Set the field expression for the label
        },
        symbol: {
            type: "text",
            color: "black",
            font: {
                family: "Arial",
                size: 12,
                weight: "bold"
            },
            haloColor: "white",
            haloSize: 2,
        },
    }],
    popupTemplate: {
        title: `
            <h4>Community District<h4/>
            <h1>{BoroCD}<h1/>
            <hr>
        `,
        outFields: ["*"],
    }
};
// Congressional Districts
const congressionalDistrictsRenderer = {
type: "simple",
symbol: {
    type: "simple-fill",
    color: null,
    outline: {
        color: "#ED00D4",
        width: 2
    }
}
};
const congressionalDistrictsObj = {
    id: 'congressionalDistricts',
    title: 'Congressional Districts',
    url: 'https://gis.nycdot.nyc/arcgis/rest/services/GAZETTEER/NYCDOTBasemapAdminBoundaries/MapServer/2',
    renderer: congressionalDistrictsRenderer,
    visible: false,
    minScale: 0,
    labelsVisible: true,
    labelingInfo: [{
        labelExpressionInfo: {
            expression: "$feature.CongDist" // Set the field expression for the label
        },
        symbol: {
            type: "text",
            color: "black",
            font: {
                family: "Arial",
                size: 12,
                weight: "bold"
            },
            haloColor: "white",
            haloSize: 2,
        },
    }],
    popupTemplate: {
        title: `
            <h4>Congressional District<h4/>
            <h1>{CongDist}<h1/>
            <hr>
        `,
        content: (feature) => {
            // Custom JavaScript logic to find the corresponding Member based on CounDist
            var noValue = feature.graphic.attributes.CongDist;
            var matchingApiItem = members["CongressApiData"].find(item => item["district"] == noValue);
  
            // Return HTML content for the popup
            return `
                <h2><span style="font-weight: lighter;">Member: </span>${matchingApiItem ? matchingApiItem.name : 'Member not found'}</h2>
            `;
        },
        outFields: ["*"],
    }
};
  
// State Assembly Districts
const stateAssemblyDistrictsRenderer = { 
    type: "simple",
    symbol: {
        type: "simple-fill",
        color: null,
        outline: {
            color: "#377eb8",
            width: 2
        }
    }
};
const stateAssemblyDistrictsObj = {
    id: 'stateAssemblyDistricts',
    title: 'State Assembly Districts',
    url: 'https://gis.nycdot.nyc/arcgis/rest/services/GAZETTEER/NYCDOTBasemapAdminBoundaries/MapServer/6',
    renderer: stateAssemblyDistrictsRenderer,
    visible: false,
    labelsVisible: true,
    labelingInfo: [{
        labelExpressionInfo: {
            expression: "$feature.AssemDist" // Set the field expression for the label
        },
        symbol: {
            type: "text",
            color: "black",
            font: {
                family: "Arial",
                size: 12,
                weight: "bold"
            },
            haloColor: "white",
            haloSize: 2,
        },
    }],
    popupTemplate: {
        title: `
            <h4>State Assembly District<h4/>
            <h1>{AssemDist}<h1/>
            <hr>
        `,
        content: (feature) => {
            // Custom JavaScript logic to find the corresponding Member based on CounDist
            var noValue = feature.graphic.attributes.AssemDist;
            var matchingApiItem = members['assemblyApiData'].find(item => item["id"] === noValue);
  
            // Return HTML content for the popup
            return `
                <h2><span style="font-weight: lighter;">Member: </span>${matchingApiItem ? matchingApiItem.properties.Name : 'Member not found'}</h2>
            `;
        },
        outFields: ["*"],
    }
};
  // State Senate Districts
const stateSenateDistrictsRenderer = {
    type: "simple",
    symbol: {
        type: "simple-fill",
        color: null,
        outline: {
            color: "#4daf4a",
            width: 2
        }
    }
};
const stateSenateDistrictsObj = {
    id: 'stateSenateDistricts',
    title: 'State Senate Districts',
    url: 'https://gis.nycdot.nyc/arcgis/rest/services/GAZETTEER/NYCDOTBasemapAdminBoundaries/MapServer/7',
    renderer: stateSenateDistrictsRenderer,
    visible: false,
    labelsVisible: true,
    labelingInfo: [{
        labelExpressionInfo: {
            expression: "$feature.StSenDist" // Set the field expression for the label
        },
        symbol: {
            type: "text",
            color: "black",
            font: {
                family: "Arial",
                size: 12,
                weight: "bold"
            },
            haloColor: "white",
            haloSize: 2,
        },
    }],
    popupTemplate: {
        title: `
            <h4>State Senate District<h4/>
            <h1>{StSenDist}<h1/>
            <hr>
        `,
        content: (feature) => {
            // Custom JavaScript logic to find the corresponding Member based on CounDist
            var noValue = feature.graphic.attributes.StSenDist;
            var matchingApiItem = members["SenateApiData"].find(item => item["districtCode"] === noValue);
  
            // Return HTML content for the popup
            return `        
                <h2><span style="font-weight: lighter;">Member: </span>${matchingApiItem ? matchingApiItem.fullName : 'Member not found'}</h2>
            `;
        },
        outFields: ["*"],
    }
};
// NTA 2020
const NTA2020Renderer = {
    type: "simple",
    symbol: {
        type: "simple-fill",
        color: null,
        outline: {
            color: "#362FD9",
            width: 2
        }
    }
};
const NTA2020DistrictsObj = {
    id: 'nta2020Districts',
    title: 'Neighborhood Tabulation Areas',
    url: 'https://gis.nycdot.nyc/arcgis/rest/services/GAZETTEER/Neighborhood_Tabulation_Areas_2020/MapServer/0',
    renderer: NTA2020Renderer,
    visible: false,
    labelsVisible: false,
    labelingInfo: {
        id: 'NTA2020',
        projDesc: 'NTAName'
    },
    popupTemplate: {
        title: `
            <h4>{NTA2020}<h4/>
            <h2>{NTAName}</h2>
            <hr>
        `,
        content: `
            <br/>
            <h2><span style="font-weight: lighter;">Borough Name: </span>{BoroName}</h2>
        `,
        outFields: ["*"],
    }
};

//////// table templates for feature tables //////////

const tableTemplate1 = {
  columnTemplates: [{
          type: 'field',
          fieldName: 'Division',
          label: 'Division'
      },
      {
          type: 'field',
          fieldName: 'FMSID',
          label: 'FMS ID'
      },
      {
          type: 'field',
          fieldName: 'PROJ_ID_DE',
          label: 'Description'
      },
      {
          type: 'field',
          fieldName: 'PROJ_ID_DESC',
          label: 'Description'
      },
      {
          type: 'field',
          fieldName: 'FYCons',
          label: 'FY Construction'
      },
      {
          type: 'field',
          fieldName: 'FY',
          label: 'FY Construction'
      },
      {
          type: 'field',
          fieldName: 'FYDesign',
          label: 'FY Design'
      },
      {
          type: 'field',
          fieldName: 'FundStatus',
          label: 'Funding Status'
      },
      {
          type: 'field',
          fieldName: 'ProjStatus',
          label: 'Project Status'
      },
      {
          type: 'field',
          fieldName: 'Cost',
          label: 'Cost'
      },
      {
          type: 'field',
          fieldName: 'Planned_Or_Committed',
          label: 'Commitment Status'
      },
      {
          type: 'field',
          fieldName: 'BoroName',
          label: 'Borough'
      },
      {
          type: 'field',
          fieldName: 'BoroCD',
          label: 'Community Board'
      },
      {
          type: 'field',
          fieldName: 'CounDist',
          label: 'Council District'
      },
      // {
      //     type: 'field',
      //     fieldName: 'CountDistMember',
      //     label: 'Council District Representative'
      // },
      {
          type: 'field',
          fieldName: 'AssemDist',
          label: 'Assembly District'
      },
      // {
      //     type: 'field',
      //     fieldName: 'AssemDistMember',
      //     label: 'Assembly District Representative'
      // },
      {
          type: 'field',
          fieldName: 'StSenDist',
          label: 'State Senator District'
      },
      // {
      //     type: 'field',
      //     fieldName: 'StSenDistMember',
      //     label: 'State Senator District Representative'
      // },
      {
          type: 'field',
          fieldName: 'CongDist',
          label: 'Congressional District'
      },
      // {
      //     type: 'field',
      //     fieldName: 'CongDistMember',
      //     label: 'Congressional District Representative'
      // },
      {
          type: 'field',
          fieldName: 'NTAName',
          label: 'NTA'
      },
      {
          type: 'field',
          fieldName: 'FY01',
          label: 'FY01'
      },
      {
          type: 'field',
          fieldName: 'FY02',
          label: 'FY02'
      },
      {
          type: 'field',
          fieldName: 'FY03',
          label: 'FY03'
      },
      {
          type: 'field',
          fieldName: 'FY04',
          label: 'FY04'
      },
      {
          type: 'field',
          fieldName: 'FY05',
          label: 'FY05'
      },
      {
          type: 'field',
          fieldName: 'FY06',
          label: 'FY06'
      },
      {
          type: 'field',
          fieldName: 'FY07',
          label: 'FY07'
      },
      {
          type: 'field',
          fieldName: 'FY08',
          label: 'FY08'
      },
      {
          type: 'field',
          fieldName: 'FY09',
          label: 'FY09'
      },
      {
          type: 'field',
          fieldName: 'FY10',
          label: 'FY10'
      },
      {
          type: 'field',
          fieldName: 'FY11',
          label: 'FY11'
      },
      {
          type: 'field',
          fieldName: 'FY12',
          label: 'FY12'
      },
      {
          type: 'field',
          fieldName: 'FY13',
          label: 'FY13'
      },
      {
          type: 'field',
          fieldName: 'FY14',
          label: 'FY14'
      },
      {
          type: 'field',
          fieldName: 'FY15',
          label: 'FY15'
      },
      {
          type: 'field',
          fieldName: 'FY16',
          label: 'FY16'
      },
      {
          type: 'field',
          fieldName: 'FY17',
          label: 'FY17'
      },
      {
          type: 'field',
          fieldName: 'FY18',
          label: 'FY18'
      },
      {
          type: 'field',
          fieldName: 'FY19',
          label: 'FY19'
      },
      {
          type: 'field',
          fieldName: 'FY20',
          label: 'FY20'
      },
      {
          type: 'field',
          fieldName: 'FY21',
          label: 'FY21'
      },
      {
          type: 'field',
          fieldName: 'FY22',
          label: 'FY22'
      },
      {
          type: 'field',
          fieldName: 'FY23',
          label: 'FY23'
      },
      {
          type: 'field',
          fieldName: 'FY24',
          label: 'FY24'
      },
      {
          type: 'field',
          fieldName: 'FY25',
          label: 'FY25'
      },
      {
          type: 'field',
          fieldName: 'FY26',
          label: 'FY26'
      },
      {
          type: 'field',
          fieldName: 'FY27',
          label: 'FY27'
      },
      {
          type: 'field',
          fieldName: 'FY28',
          label: 'FY28'
      },
      {
          type: 'field',
          fieldName: 'FY29',
          label: 'FY29'
      },
      {
          type: 'field',
          fieldName: 'FY30',
          label: 'FY30'
      },
      {
          type: 'field',
          fieldName: 'FY31',
          label: 'FY31'
      },
      {
          type: 'field',
          fieldName: 'FY32',
          label: 'FY32'
      },
      {
          type: 'field',
          fieldName: 'FY33',
          label: 'FY33'
      },
      
  ]
};

const tableTemplate2 = {
  columnTemplates: [{
          type: 'field',
          fieldName: 'Division',
          label: 'Division'
      },
      {
          type: 'field',
          fieldName: 'FMSID',
          label: 'FMS ID'
      },
      {
          type: 'field',
          fieldName: 'PROJ_ID_DE',
          label: 'Description'
      },
      {
          type: 'field',
          fieldName: 'PROJ_ID_DESC',
          label: 'Description'
      },
      {
          type: 'field',
          fieldName: 'FYCons',
          label: 'FY Construction'
      },
      {
          type: 'field',
          fieldName: 'FY',
          label: 'FY Construction'
      },
      {
          type: 'field',
          fieldName: 'FYDesign',
          label: 'FY Design'
      },
      {
          type: 'field',
          fieldName: 'FundStatus',
          label: 'Funding Status'
      },
      {
          type: 'field',
          fieldName: 'ProjStatus',
          label: 'Project Status'
      },
      {
          type: 'field',
          fieldName: 'Planned_Or_Committed',
          label: 'Commitment Status'
      },
      {
          type: 'field',
          fieldName: 'BoroName',
          label: 'Borough'
      },
      {
          type: 'field',
          fieldName: 'BoroCD',
          label: 'Community Board'
      },
      {
          type: 'field',
          fieldName: 'CounDist',
          label: 'Council District'
      },
      // {
      //     type: 'field',
      //     fieldName: 'CountDistMember',
      //     label: 'Council District Representative'
      // },
      {
          type: 'field',
          fieldName: 'AssemDist',
          label: 'Assembly District'
      },
      // {
      //     type: 'field',
      //     fieldName: 'AssemDistMember',
      //     label: 'Assembly District Representative'
      // },
      {
          type: 'field',
          fieldName: 'StSenDist',
          label: 'State Senator District'
      },
      // {
      //     type: 'field',
      //     fieldName: 'StSenDistMember',
      //     label: 'State Senator District Representative'
      // },
      {
          type: 'field',
          fieldName: 'CongDist',
          label: 'Congressional District'
      },
      // {
      //     type: 'field',
      //     fieldName: 'CongDistMember',
      //     label: 'Congressional District Representative'
      // },
      {
          type: 'field',
          fieldName: 'NTAName',
          label: 'NTA'
      },
      {
          type: 'field',
          fieldName: 'FY01',
          label: 'FY01'
      },
      {
          type: 'field',
          fieldName: 'FY02',
          label: 'FY02'
      },
      {
          type: 'field',
          fieldName: 'FY03',
          label: 'FY03'
      },
      {
          type: 'field',
          fieldName: 'FY04',
          label: 'FY04'
      },
      {
          type: 'field',
          fieldName: 'FY05',
          label: 'FY05'
      },
      {
          type: 'field',
          fieldName: 'FY06',
          label: 'FY06'
      },
      {
          type: 'field',
          fieldName: 'FY07',
          label: 'FY07'
      },
      {
          type: 'field',
          fieldName: 'FY08',
          label: 'FY08'
      },
      {
          type: 'field',
          fieldName: 'FY09',
          label: 'FY09'
      },
      {
          type: 'field',
          fieldName: 'FY10',
          label: 'FY10'
      },
      {
          type: 'field',
          fieldName: 'FY11',
          label: 'FY11'
      },
      {
          type: 'field',
          fieldName: 'FY12',
          label: 'FY12'
      },
      {
          type: 'field',
          fieldName: 'FY13',
          label: 'FY13'
      },
      {
          type: 'field',
          fieldName: 'FY14',
          label: 'FY14'
      },
      {
          type: 'field',
          fieldName: 'FY15',
          label: 'FY15'
      },
      {
          type: 'field',
          fieldName: 'FY16',
          label: 'FY16'
      },
      {
          type: 'field',
          fieldName: 'FY17',
          label: 'FY17'
      },
      {
          type: 'field',
          fieldName: 'FY18',
          label: 'FY18'
      },
      {
          type: 'field',
          fieldName: 'FY19',
          label: 'FY19'
      },
      {
          type: 'field',
          fieldName: 'FY20',
          label: 'FY20'
      },
      {
          type: 'field',
          fieldName: 'FY21',
          label: 'FY21'
      },
      {
          type: 'field',
          fieldName: 'FY22',
          label: 'FY22'
      },
      {
          type: 'field',
          fieldName: 'FY23',
          label: 'FY23'
      },
      {
          type: 'field',
          fieldName: 'FY24',
          label: 'FY24'
      },
      {
          type: 'field',
          fieldName: 'FY25',
          label: 'FY25'
      },
      {
          type: 'field',
          fieldName: 'FY26',
          label: 'FY26'
      },
      {
          type: 'field',
          fieldName: 'FY27',
          label: 'FY27'
      },
      {
          type: 'field',
          fieldName: 'FY28',
          label: 'FY28'
      },
      {
          type: 'field',
          fieldName: 'FY29',
          label: 'FY29'
      },
      {
          type: 'field',
          fieldName: 'FY30',
          label: 'FY30'
      },
      {
          type: 'field',
          fieldName: 'FY31',
          label: 'FY31'
      },
      {
          type: 'field',
          fieldName: 'FY32',
          label: 'FY32'
      },
      {
          type: 'field',
          fieldName: 'FY33',
          label: 'FY33'
      }
  ]
};

// Define the order of columns for export, can put in each individual later
let reorderedHeaders = {
  //Street Reconstruction
  0: ['OBJECTID', 'BoroCode', 'BoroName', 'BoroCD', 'CounDist', 'CounDistMember', 'AssemDist', 'AssemDistMember', 'StSenDist', 'StSenDistMember', 'CongDist', 'CongDistMember', 'Division', 'FMSID', 'PROJ_ID_DESC', 'FYCons', 'FYDesign', 'FundStatus', 'ProjStatus', 'Cost', 'Planned_Or_Committed', 'FY01', 'FY02', 'FY03', 'FY04', 'FY05', 'FY06', 'FY07', 'FY08', 'FY09', 'FY10', 'FY11', 'FY12', 'FY13', 'FY14', 'FY15', 'FY16', 'FY17', 'FY18', 'FY19', 'FY20', 'FY21', 'FY22', 'FY23', 'FY24', 'FY25', 'FY26', 'FY27', 'FY28', 'FY29', 'FY30', 'FY31', 'FY32', 'FY33', 'FEMAFldz', 'FEMAFldT', 'HrcEvac', 'NTAName', 'FMSID2'],

  //Pedestrian Ramps
  1: ['OBJECTID', 'BoroCode', 'BoroName', 'BoroCD', 'CounDist', 'CounDistMember', 'AssemDist', 'AssemDistMember', 'StSenDist', 'StSenDistMember', 'CongDist', 'CongDistMember', 'Division', 'FMSID', 'PROJ_ID_DE', 'FYCons', 'FYDesign', 'Cost', 'Planned_Or_Committed', 'FY01', 'FY02', 'FY03', 'FY04', 'FY05', 'FY06', 'FY07', 'FY08', 'FY09', 'FY10', 'FY11', 'FY12', 'FY13', 'FY14', 'FY15', 'FY16', 'FY17', 'FY18', 'FY19', 'FY20', 'FY21', 'FY22', 'FY23', 'FY24', 'FY25', 'FY26', 'FY27', 'FY28', 'FY29', 'FY30', 'FY31', 'FY32', 'FY33', 'FEMAFldz', 'FEMAFldT', 'HrcEvac', 'NTAName', 'SHAPE'],

  //Bridges
  2: ['OBJECTID', 'BoroCode', 'BoroName', 'BoroCD', 'CounDist', 'CounDistMember', 'AssemDist', 'AssemDistMember', 'StSenDist', 'StSenDistMember', 'CongDist', 'CongDistMember', 'Division', 'FMSID', 'PROJ_ID_DE', 'FYCons', 'FYDesign', 'FundStatus', 'ProjStatus', 'Cost', 'Planned_Or_Committed', 'BIN', 'FY01', 'FY02', 'FY03', 'FY04', 'FY05', 'FY06', 'FY07', 'FY08', 'FY09', 'FY10', 'FY11', 'FY12', 'FY13', 'FY14', 'FY15', 'FY16', 'FY17', 'FY18', 'FY19', 'FY20', 'FY21', 'FY22', 'FY23', 'FY24', 'FY25', 'FY26', 'FY27', 'FY28', 'FY29', 'FY30', 'FY31', 'FY32', 'FY33', 'FEMAFldz', 'FEMAFldT', 'HrcEvac', 'NTAName', 'FMSID2', 'SHAPE'],

  //Facilities
  3: ['OBJECTID', 'BoroCode', 'BoroName', 'BoroCD', 'CounDist', 'CounDistMember', 'AssemDist', 'AssemDistMember', 'StSenDist', 'StSenDistMember', 'CongDist', 'CongDistMember', 'Division', 'FMSID', 'PROJ_ID_DE', 'FYCons', 'FYDesign', 'FundStatus', 'ProjStatus', 'Cost', 'Planned_Or_Committed', 'FY01', 'FY02', 'FY03', 'FY04', 'FY05', 'FY06', 'FY07', 'FY08', 'FY09', 'FY10', 'FY11', 'FY12', 'FY13', 'FY14', 'FY15', 'FY16', 'FY17', 'FY18', 'FY19', 'FY20', 'FY21', 'FY22', 'FY23', 'FY24', 'FY25', 'FY26', 'FY27', 'FY28', 'FY29', 'FY30', 'FY31', 'FY32', 'FY33', 'FMSID2', 'FEMAFldz', 'FEMAFldT', 'HrcEvac', 'NTAName'],

  //Ferries
  4: ['OBJECTID', 'BoroCode', 'BoroName', 'BoroCD', 'CounDist', 'CounDistMember', 'AssemDist', 'AssemDistMember', 'StSenDist', 'StSenDistMember', 'CongDist', 'CongDistMember', 'Division', 'FMSID', 'PROJ_ID_DE', 'FYCons', 'FYDesign', 'FundStatus', 'ProjStatus', 'Cost', 'Planned_Or_Committed', 'FY01', 'FY02', 'FY03', 'FY04', 'FY05', 'FY06', 'FY07', 'FY08', 'FY09', 'FY10', 'FY11', 'FY12', 'FY13', 'FY14', 'FY15', 'FY16', 'FY17', 'FY18', 'FY19', 'FY20', 'FY21', 'FY22', 'FY23', 'FY24', 'FY25', 'FY26', 'FY27', 'FY28', 'FY29', 'FY30', 'FY31', 'FY32', 'FY33', 'FEMAFldz', 'FEMAFldT', 'HrcEvac', 'NTAName', 'SHAPE'],

  //Resurfacing
  5: ['OBJECTID', 'BoroName', 'BoroCD', 'CounDist', 'CounDistMember', 'AssemDist', 'AssemDistMember', 'StSenDist', 'StSenDistMember', 'CongDist', 'CongDistMember', 'Division', 'CapitalProjectID', 'Cost', 'ActualEndDate', 'FY', 'FEMAFldz', 'FEMAFldT', 'HrcEvac', 'NTAName', 'Shape'],

  //Sidewalks Prior Notice
  6: ['OBJECTID', 'BoroCode', 'BoroName', 'BoroCD', 'CounDist', 'CounDistMember', 'AssemDist', 'AssemDistMember', 'StSenDist', 'StSenDistMember', 'CongDist', 'CongDistMember', 'Division', 'Contract', 'FMSID', 'PROJ_ID_DE', 'FYCons', 'FYDesign', 'FundStatus', 'ProjStatus', 'Cost', 'Planned_Or_Committed', 'FY01', 'FY02', 'FY03', 'FY04', 'FY05', 'FY06', 'FY07', 'FY08', 'FY09', 'FY10', 'FY11', 'FY12', 'FY13', 'FY14', 'FY15', 'FY16', 'FY17', 'FY18', 'FY19', 'FY20', 'FY21', 'FY22', 'FY23', 'FY24', 'FY25', 'FY26', 'FY27', 'FY28', 'FY29', 'FY30', 'FY31', 'FY32', 'FY33', 'FEMAFldz', 'FEMAFldT', 'HrcEvac', 'NTAName']
  
  };
  