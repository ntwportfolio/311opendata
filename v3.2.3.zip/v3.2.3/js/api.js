const apiUrlCouncil = "https://data.cityofnewyork.us/resource/uvw5-9znb.json";

const apiUrlAssembly = "https://services6.arcgis.com/EbVsqZ18sv1kVJ3k/arcgis/rest/services/NYS_Assembly_Districts/FeatureServer/0/query?outFields=*&where=1%3D1&f=geojson";

// const apiUrlSenate = "https://legislation.nysenate.gov/api/3/members/search?term=status:active&key=h7XFZYS7OwhCbSMeJoHtNpWTHZ6y3mQc"
const apiUrlSenate = (year) => `https://legislation.nysenate.gov/api/3/members/${year}/senate?full=true&limit=100&key=h7XFZYS7OwhCbSMeJoHtNpWTHZ6y3mQc`
// const apiUrlSenate = "https://legislation.nysenate.gov/api/3/members/2024/house?key=h7XFZYS7OwhCbSMeJoHtNpWTHZ6y3mQc"

const apiUrlCongress = "https://api.congress.gov/v3/member?api_key=YskirA9JaaO48rLhdV5iaGbqfwGO88raaiCFOfzL"

