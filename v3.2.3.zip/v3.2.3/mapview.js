require(["esri/Map", "esri/views/MapView", "esri/layers/FeatureLayer",
    "esri/widgets/Legend", "esri/widgets/BasemapToggle", "esri/widgets/Search",
    "esri/widgets/Sketch", "esri/layers/GraphicsLayer", "esri/config", "esri/request",
    "esri/widgets/Expand", "esri/layers/support/Field", "esri/Graphic", "esri/layers/GroupLayer",
    "esri/widgets/LayerList", "esri/widgets/BasemapGallery", "esri/widgets/Sketch/SketchViewModel",
    "esri/widgets/FeatureTable", "esri/geometry/geometryEngineAsync", "esri/widgets/TimeSlider", "esri/widgets/Slider",
    "esri/widgets/Feature", "esri/core/promiseUtils", "esri/widgets/FeatureTable/Grid/support/ButtonMenu", /*"esri/layers/JoinTableDataSource",*/
    "esri/core/reactiveUtils", "esri/request",
], (
    Map,
    MapView,
    FeatureLayer,
    Legend,
    BasemapToggle,
    Search,
    Sketch,
    GraphicsLayer,
    esriConfig,
    request,
    Expand,
    Field,
    Graphic,
    GroupLayer,
    LayerList,
    BasemapGallery,
    SketchViewModel,
    FeatureTable,
    geometryEngineAsync,
    TimeSlider,
    Slider,
    Feature,
    promiseUtils,
    ButtonMenu,
    //JoinTableDataSource,
    reactiveUtils,
    esriRequest,
) => {

    let currentDate = new Date();

    let members = {
        "assemblyApiData": [],
        "CouncilApiData": [],
        "CongressApiData": [],
        "SenateApiData": [],
    }

    // Create URLSearchParams and pass it into the esriRequest options query parameter.
    // This can be a plain object or URLSearchParams object.
    const urlSearchParams = new URLSearchParams({
        f: "json"
    });

    // Create a ReqeuestOptions object with the URLSearchParams as the query parameter.
    // Other parameters can be specified if needed.
    const options = {
        query: urlSearchParams
    };

    // Function to call esriRequest with async/await.
    async function makeCouncilRequest(url, options) {

        // Use try/catch for error handling.
        try {
            // Use async/await to wait for the response to return
            // from the service.
            const response = await esriRequest(url, options);

            members["CouncilApiData"] = response.data
            // if(response.length){
            // }
        } catch (error) {
            // If an error is returned in the response, display the error alongside the http status code.
            console.log(`${error.details.httpStatus} error: "${error.message}."`)
        }

    }

    async function makeCongressRequest(url, options) {

        // Use try/catch for error handling.
        try {
            // Use async/await to wait for the response to return
            // from the service.
            const response = await esriRequest(url, options);
            if(!count){
                count = response.data.pagination.count
            }

            response.data.members && response.data.members.forEach((obj, i) => {
                if(obj.state === "New York"){
                    if(!obj.terms.item[0].endYear){
                        let nameArr = obj.name.split(', ')
                        let newObj = obj
                        newObj.name = `${nameArr[1]} ${nameArr[0]}`

                        members["CongressApiData"].push(newObj)
                    }
                }
            })
            
            count -= 250;
            offset += 250;
            handleCongressApiResults()

        } catch (error) {
            // If an error is returned in the response, display the error alongside the http status code.
            console.log(`${error.details.httpStatus} error: "${error.message}."`)
        }

    }

    async function makeAssemblyRequest(url, options) {

        // Use try/catch for error handling.
        try {
            // Use async/await to wait for the response to return
            // from the service.
            const response = await esriRequest(url, options);

            members["assemblyApiData"] = response.data.features
            // if(response.length){
            // }
        } catch (error) {
            // If an error is returned in the response, display the error alongside the http status code.
            console.log(`${error.details.httpStatus} error: "${error.message}."`)
        }

    }

    async function makeSenateRequest(url, options) {
        // Use try/catch for error handling.
        try {
            // Use async/await to wait for the response to return
            // from the service.
            const response = await esriRequest(url, options);

            const result = response.data.result.items

            members["SenateApiData"] = result

        } catch (error) {
            // If an error is returned in the response, display the error alongside the http status code.
            console.log(`${error.details.httpStatus} error: "${error.message}."`)
        }

    }

    makeCouncilRequest(apiUrlCouncil, options);
    makeAssemblyRequest(apiUrlAssembly, options);
    makeSenateRequest(apiUrlSenate(currentDate.getFullYear()), options);

    //congress API
    let startDate;
    startDate = new Date()
    startDate.setFullYear(2022) // latest updatedate for some current members
    // startDate.setFullYear(currentDate.getFullYear() - 1)

    currentDate = currentDate.toISOString()
    startDate = startDate.toISOString()

    let congressOptions = {
        query: {
            limit: 250,
            offset: 0,
            fromDateTime: `${startDate.split('T')[0]}T00:00:00Z`,
            toDateTime: `${currentDate.split('T')[0]}T00:00:00Z`,
            ...urlSearchParams
        }
    };

    let count = 0;
    let offset = 0;

    makeCongressRequest(apiUrlCongress, congressOptions); // first request 

    function handleCongressApiResults(){ // if the pagination count is greater than 250 rows
        if(count > 0){
            congressOptions = {
                query: {
                    limit: 250,
                    offset: offset,
                    fromDateTime: `${startDate.split('T')[0]}T00:00:00Z`,
                    toDateTime: `${currentDate.split('T')[0]}T00:00:00Z`,
                    ...urlSearchParams
                }
            };
            makeCongressRequest(apiUrlCongress, congressOptions);
        } else {
            const congressBtn = document.getElementById("congressBtn")
            congressBtn && congressBtn.classList.remove("disabled")
        }

    }

    dataTabcontent()
    aboutContent()

    const map = new Map({
        basemap: "gray-vector"
    });
    const view = new MapView({
        container: "viewDiv",
        map: map,
        zoom: 13,
        center: [-73.989032, 40.684078],
    });

    view.when().then(() => {
        const layers = [
            sidewalks,
            resurfacing,
            ferries,
            facilities,
            bridges,
            pedRamps,
            streets,
            NTA2020Districts,
            cityCouncilDistricts,
            communityDistricts,
            congressionalDistricts,
            stateAssemblyDistricts,
            stateSenateDistricts,
        ]
        // const sidePanelDefaultContent = "<b><h1> Welcome to Capital Projects Map </h1></b>"

        SidePanelFunc({ 
            view, 
            searchWidget, 
            Feature, 
            layers, 
            promiseUtils, 
            // sidePanelDefaultContent,
            slider,
            featureTable,
            groupLayer,
            sketchViewModel
        });

        // console.log("members", members)

        handleModalContent('about-content')

        const cityCounBtn = document.getElementById("cityCounBtn");
        const senateBtn = document.getElementById("senateBtn");
        const assemblyBtn = document.getElementById("assemblyBtn");
        const congressBtn = document.getElementById("congressBtn");

        const sidewalksBtn = document.getElementById("sidewalksBtn");
        const resurfacingBtn = document.getElementById("resurfacingBtn");
        const ferriesBtn = document.getElementById("ferriesBtn");
        const facilitiesBtn = document.getElementById("facilitiesBtn");
        const bridgesBtn = document.getElementById("bridgesBtn");
        const pedRampsBtn = document.getElementById("pedRampsBtn");
        const streetsBtn = document.getElementById("streetsBtn");
    
        
        cityCounBtn.addEventListener("click", (event) =>{
            const headers = {
                District: "District1",
                Representative: "Representative",
                Political_Party: "Political_Party",
                Borough: "Borough"
            }
            const toExport = members.CouncilApiData.map((el) => {
                return({
                    District: el.district,
                    Representative: el.name,
                    Political_Party: el.political_party,
                    Borough: el.borough
                })
            })
            exportMembersCSVFile(headers, toExport, 'cityCouncil_Representatives')
        })
        senateBtn.addEventListener("click", (event) =>{
            const headers = {
                District: "District1",
                Representative: "Representative",
            }
            const toExport = members.SenateApiData.map((el) => {
                return({
                    District: el.districtCode,
                    Representative: el.fullName,
                })
            })

            exportMembersCSVFile(headers, toExport.sort(sort_by_district_code()), 'stateSenate_Representatives')
        })
        assemblyBtn.addEventListener("click", (event) =>{
            const headers = {
                District: "District1",
                Representative: "Representative",
                Political_Party: "Political_Party"
            }
            const toExport = members.assemblyApiData.map((el) => {
                return({
                    District: el.properties.District,
                    Representative: el.properties.Name,
                    Political_Party: el.properties.Party
                })
            })
            exportMembersCSVFile(headers, toExport, 'stateAssembly_Representatives')
        })
        congressBtn.addEventListener("click", (event) =>{
            const headers = {
                District: "District1",
                Representative: "Representative",
                Political_Party: "Political_Party"
            }
            const toExport = members.CongressApiData.map((el) => {
                return({
                    District: el.district,
                    Representative: el.name,
                    Political_Party: el.partyName
                })
            })
            exportMembersCSVFile(headers, toExport.sort(sort_by_district_code()), 'congressional_Representatives')
        })

        sidewalksBtn.addEventListener("click", downloadAttributes)
        resurfacingBtn.addEventListener("click", downloadAttributes)
        ferriesBtn.addEventListener("click", downloadAttributes)
        facilitiesBtn.addEventListener("click", downloadAttributes)
        bridgesBtn.addEventListener("click", downloadAttributes)
        pedRampsBtn.addEventListener("click", downloadAttributes)
        streetsBtn.addEventListener("click", downloadAttributes)

        const layersByBtn = {
            sidewalksBtn: sidewalks,
            resurfacingBtn: resurfacing,
            ferriesBtn: ferries,
            facilitiesBtn: facilities,
            bridgesBtn: bridges,
            pedRampsBtn: pedRamps,
            streetsBtn: streets
        };

        let start = 0;
        let isExceeded = false;
        function getFeaturesByQuery(exceededLimit, layer, btn) {
            //Select all downloadBtn
            const htmlCollection = document.getElementsByClassName('downloadBtn')
            if(!exceededLimit){
                const index = groupLayer.allLayers
                        .findIndex(item => item.id === layer.id)
                toExport(layer.id, index)
                document.getElementById(btn).classList = 'esri-icon-download downloadBtn'
                for (let i = 0; i < htmlCollection.length; i++) {
                    const node = htmlCollection[i];
                    node.classList.remove('disabled')
                }
                return;
            }

            // add loading animation
            document.getElementById(btn).classList = 'loader'

            
            // disable the rest of btns
            for (let i = 0; i < htmlCollection.length; i++) {
                const node = htmlCollection[i];
                node.classList.add('disabled')
            }

            const query = {
                start,
                num: 1000, //highest num of retrieves possible
                outFields: ["*"],
                returnGeometry: false,
                // orderByFields: ["MEDHINC_CY DESC"]
              };
              const promise = layer
                .queryFeatures(query)
                .then((featureSet) => {
                    start += 1000;
                    isExceeded = featureSet.exceededTransferLimit
                    // console.log(featureSet.exceededTransferLimit)
                    const features = resultFeatures.concat(featureSet.features);
                    resultFeatures = features;
                    getFeaturesByQuery(isExceeded, layer, btn)
                });
        }

        function downloadAttributes(event) {
            const btn = event.target.id;
            start = 0;
            isExceeded = true;
            resultFeatures = [];
            getFeaturesByQuery(isExceeded, layersByBtn[btn], btn);
        }


        const layerListCointainer = document.createElement('div')
        layerListCointainer.id = 'layerContainer'
        layerListCointainer.style.backgroundColor = 'white'
        const layersTab = document.getElementById('tab2Container');
        layersTab.appendChild(layerListCointainer)
        layerList.container = layerListCointainer

        const bgModal = document.getElementById('bg-modal')
        bgModal.addEventListener("click", (event) => {
            closeModal()
        })
        
    });

    ///////////////////////////////// Add basemap gallery /////////////////////////
    const basemapGallery = new BasemapGallery({
        view: view,
        container: document.createElement('div')
    });

    const bgExpand = new Expand({
        view: view,
        content: basemapGallery,
        expandTooltip: 'Change Basemap'
    });
    
    view.ui.add("btn-collapse-sidePanel", "top-left");

    view.ui.add(bgExpand, {
        position: 'top-left'
    });


    // Toggle sidepanel
    document.getElementById("btn-collapse-sidePanel").addEventListener("click", function(event){
        const isExpanded =  document.getElementById("sidePanel").style.display == "flex"

        // show/hide sidepanel container
        document.getElementById("sidePanel").style.display = isExpanded
            ? "none"
            : "flex"
        // switch arrow
        document.getElementById("sidepanel-collapse-btn").className = isExpanded
            ? "esri-icon-right"
            : "esri-icon-left"
        // Change tooltip
        document.getElementById("sidepanel-collapse-btn").title = isExpanded
            ? "Show Side Panel"
            : "Collapse Side Panel"
        // Expand/shrink the view
        document.getElementById("viewDiv").style.width = isExpanded
            ? "100%"
            : "80%"
        
    })

    /////////////////////////// Date filter Slider /////////////////////////////////////////////////

    const slider = new Slider({
        min: 2000,
        max: 2034,
        values: [2000, 2034],
        steps: 1,
        snapOnClickEnabled: true,
        // tickConfigs: [{
        //     mode: 'position',
        //     values: [2005, 2017, 2028],
        //     labelsVisible: true
        // }],
        visibleElements: {
            labels: true,
            rangeLabels: true
        },
        disabled: false,
    });

    view.ui.add(slider, "manually");
    // Filter layerviews
    let timequery;
    let lvIndex;
    slider.on(["thumb-change", "thumb-drag"], ({
        state
    }) => {
        if (state != "stop") return;
        view.layerViews.items["1"].layerViews.forEach((lv, i) => {
            if (lv.layer.id === "resurfacing") {
                lv.filter = {
                    where: "FY BETWEEN '" + slider.values[0] + "' AND '" + slider.values[1] + "'"
                }
            } else {
                timequery = {
                    where: "FYCons BETWEEN '" + slider.values[0] + "' AND '" + slider.values[1] + "'"
                };
                lv.filter = timequery;
                if(lv.visible) lvIndex = i;

            };

            // }
            // })
        });
        // update feature table
        view.whenLayerView(featureTable.layer).then(function (layerView) {
            // layerView.watch('updating', function (val) {
            //     if (!val) {

                    layerView.queryFeatures().then(async (results) => {
                        // if (featureTable.layer != resurfacing) {

                            // if(LayerView){
                            //     console.log('filterGeometry', featureTable.filterGeometry)
                            // await featureTable.queryFeatures().then(async (r) => {
                            //     viewExtentFeatures = r.features
                            //     console.log('view extent features', viewExtentFeatures)
                                
                            // })
                            // }
                            timeQueryFeatures = results.features
                            filterFeatureTableByGeometryExtent()

                            
                        // }
                    });
        });
    });

    async function filterFeaturesByTimeExtent(geometry) { // return features array
        let extentFeatures
        if(LayerView) {
            
            // featureTable.clearSelectionFilter()
            // Get a query object for the layer's current configuration
            const queryParams = LayerView.createQuery();
            // set a geometry for filtering features by a region of interest
            queryParams.geometry = geometry;
    
            let lvFeatures
            // query the layer with the modified params object
            
            await LayerView.queryFeatures(queryParams).then(function(r) {
                // prints the array of result graphics to the console
                lvFeatures = r.features;
            });

            extentFeatures = timeQueryFilter(lvFeatures)

            let trial
            LayerView.filter = timequery;
            await LayerView.queryFeatures().then(function(r) {
                // prints the array of result graphics to the console
                trial = r.features;
            });
            timeQueryFeatures = trial

            return extentFeatures
        }

        return null
    }

    function timeQueryFilter (features) {
        const timeQueryFt = timeQueryFeatures?.map(feature => feature.attributes.FMSID)
        // console.log('timeQueryFt', timeQueryFt)
        const output = features.filter(feature => timeQueryFt.includes(feature.attributes.FMSID));

        return output
    }

    function filterFeatureTableByGeometryExtent() {
        
        if(rectGeometries) {
            document.getElementById("select-by-rectangle").classList.add("active")
            selectFeatures(rectGeometries)
            document.getElementById("select-by-rectangle").classList.remove("active")
        } else {
            currentExtent()
        }


    }

    ///////////////////////////////////////// Add feature Layers ///////////////////////////////////////////////

    const streets = new FeatureLayer(streetsObj);
    const bridges = new FeatureLayer(bridgesObj);
    const ferries = new FeatureLayer(ferriesObj);
    const resurfacing = new FeatureLayer(resurfacingObj);
    const pedRamps = new FeatureLayer(pedRampsObj);
    const facilities = new FeatureLayer(facilitiesObj);
    const sidewalks = new FeatureLayer(sidewalksObj);

    const cityCouncilDistricts = new FeatureLayer(cityCouncilDistrictsObj);
    cityCouncilDistricts.popupTemplate.content = (feature) => {
        // Custom JavaScript logic to find the corresponding Member based on CounDist
        var noValue = feature.graphic.attributes.CounDist;
        var matchingApiItem = members["CouncilApiData"].find(item => item["district"] == noValue);
    
        // Return HTML content for the popup
        return `
            <h2><span style="font-weight: lighter;">Member: </span>${matchingApiItem ? matchingApiItem.name : 'Member not found'}</h2>
        `;
    }

    const communityDistricts = new FeatureLayer(communityDistrictsObj);
    const congressionalDistricts = new FeatureLayer(congressionalDistrictsObj);
    congressionalDistricts.popupTemplate.content = (feature) => {
        // Custom JavaScript logic to find the corresponding Member based on CounDist
        var noValue = feature.graphic.attributes.CongDist;
        var matchingApiItem = members["CongressApiData"].find(item => item["district"] == noValue);

        // Return HTML content for the popup
        return `
            <h2><span style="font-weight: lighter;">Member: </span>${matchingApiItem ? matchingApiItem.name : 'Member not found'}</h2>
        `;
    }

    const stateAssemblyDistricts = new FeatureLayer(stateAssemblyDistrictsObj);
    stateAssemblyDistricts.popupTemplate.content = (feature) => {
        // Custom JavaScript logic to find the corresponding Member based on CounDist
        var noValue = feature.graphic.attributes.AssemDist;
        var matchingApiItem = members['assemblyApiData'].find(item => item["id"] === noValue);

        // Return HTML content for the popup
        return `
            <h2><span style="font-weight: lighter;">Member: </span>${matchingApiItem ? matchingApiItem.properties.Name : 'Member not found'}</h2>
        `;
    }

    const stateSenateDistricts = new FeatureLayer(stateSenateDistrictsObj);
    stateSenateDistricts.popupTemplate.content = (feature) => {
        // Custom JavaScript logic to find the corresponding Member based on CounDist
        var noValue = feature.graphic.attributes.StSenDist;
        var matchingApiItem = members["SenateApiData"].find(item => item["districtCode"] === noValue);

        // Return HTML content for the popup
        return `        
            <h2><span style="font-weight: lighter;">Member: </span>${matchingApiItem ? matchingApiItem.fullName : 'Member not found'}</h2>
        `;
    }

    const NTA2020Districts = new FeatureLayer(NTA2020DistrictsObj);

    ///////////////////////////////////////////////////// Add search widget to map //////////////////////////////////////////////////////////
    const searchWidget = new Search({
        view: view,
        allPlaceholder: "FMS ID",
        includeDefaultSources: false,
        popupEnabled: false,
        // resultGraphic: graphic,
        sources: [
            {
                layer: streets,
                searchFields: ["FMSID"],
                displayField: "FMSID",
                exactMatch: false,
                outFields: ["*"],
                name: "Streets",
                placeholder: "Enter Street FMS ID"
            },
            {
                layer: bridges,
                searchFields: ["FMSID"],
                displayField: "FMSID",
                exactMatch: false,
                outFields: ["*"],
                name: "Bridges",
                placeholder: "Enter Bridge FMS ID"
            },
            {
                layer: sidewalks,
                searchFields: ["FMSID"],
                displayField: "FMSID",
                exactMatch: false,
                outFields: ["*"],
                name: "Sidewalks",
                placeholder: "Enter Sidewalk FMS ID"
            },
            {
                layer: pedRamps,
                searchFields: ["FMSID"],
                displayField: "FMSID",
                exactMatch: false,
                outFields: ["*"],
                name: "Ped Ramps",
                placeholder: "Enter Ramp FMS ID"
            },
            {
                layer: ferries,
                searchFields: ["FMSID"],
                displayField: "FMSID",
                exactMatch: false,
                outFields: ["*"],
                name: "Ferries",
                placeholder: "Enter Ferries FMS ID"
            },
            {
                layer: facilities,
                searchFields: ["FMSID"],
                displayField: "FMSID",
                exactMatch: false,
                outFields: ["*"],
                name: "Facilities",
                placeholder: "Enter Facilities FMS ID"
            }
        ]
    })
    

    view.ui.add(searchWidget, {
        position: "manually", //for moving to the Sidepanel
        //index: 2
    });

    ///////////////////////////////////////////////////// Add Group Layer and Legend to Map ////////////////////////////////

    const groupLayer = new GroupLayer({
        title: "Capital Projects",
        id: "CP",
        visible: true,
        visibilityMode: "independent",
        layers: [
            streets,
            pedRamps, 
            bridges, 
            facilities, 
            ferries, 
            resurfacing, 
            sidewalks
        ],
        opacity: 0.75,
    });
    
    const groupLayerPoliticalBoundaries = new GroupLayer({
        title: "Political Boundaries",
        id: "PB",
        visible: true,
        visibilityMode: "independent",
        layers: [
            congressionalDistricts, 
            stateAssemblyDistricts, 
            stateSenateDistricts, 
            communityDistricts, 
            cityCouncilDistricts, 
            NTA2020Districts
        ],
        opacity: 0.5,
    });

    const layerList = new LayerList({
        view: view,
        listItemCreatedFunction: defineActions
    });

    const lgExpand = new Expand({
        view: view,
        content: layerList,
        expandTooltip: 'Add Layers to Map',
        autoCollapse: false,
    });

    view.ui.add(layerList, {
        position: 'manually'
    });

    // this keeps the layerlist open on default
    function defineActions(event) {
        const item = event.item;
        /*
        // this is for both groups to stay open if need be in the future
        if (item.layer.type === "group"){
            item.open = true;
        }
        */
        // only capital projects to stay open
        if (item.layer && item.layer.id === 'CP') {
            item.open = true; // Open the 'groupLayer'
        }
    }

    map.add(groupLayerPoliticalBoundaries);
    map.add(groupLayer)

    // this only watches the CP visibility 
    // turns it back on right away lol
    groupLayer.watch('visible', (visibility, a, eventName,layer) => {
        //console.log("visible: ", visibility);
        //console.log(layer, eventName, a);
        groupLayer.visible = true;
        //console.log("visible: ", visibility);
        //console.log(layer, eventName, a);
    });

    const legend = new Legend({
        view: view
    })

    const legendExpand = new Expand({
        view: view,
        content: legend,
        expandIconClass: 'esri-icon-legend',
        expandTooltip: 'Display Legend'
    })

    // view.ui.add(legendExpand, "top-left");

    //////////////////////////////// Display Feature table and select features by rectangle  //////////////////
    // add graphics layer for drawing rectangle
    const polygonGraphicsLayer = new GraphicsLayer({
        listMode: 'hide'
    });
    map.add(polygonGraphicsLayer);

    // add the select by rectangle button the view
    view.ui.add("select-by-rectangle", "top-left");
    const selectButton = document.getElementById("select-by-rectangle");

    // automatically disable the rec selection button if no layer is visible
    groupLayer.allLayers.forEach(ly => {
        ly.watch('visible', (visible) => {
            let is_a_layer_visible = groupLayer.allLayers.find(layer => layer.visible);
            // console.log('grouplayer visibility', groupLayer)
            if(is_a_layer_visible) {
                document.getElementById("select-by-rectangle").classList.remove("disabled")
                slider.disabled = false
            } else {
                document.getElementById("select-by-rectangle").classList.add("disabled")
                slider.disabled = true
            }
            
        })
    })

    // click event for the select by rectangle button
    selectButton.addEventListener("click", () => {
        clearSelection()
        // Update feature Table layer with the last visible layer
        let index;
        const layerNameSelection = document.getElementById("layerNamesSelection")

        const currentLayer = groupLayer.allLayers.find((ly, i) => {
            if(ly.visible){
                index = i
            }
            return(ly.visible) // boolean 
        });

        if(currentLayer){
            checkbox.checked = true
            if(featureTable.layer !== currentLayer){  
                if(index != null && index !== -1) {
                    handleFetureTableLayerChange(currentLayer)
                    layerNameSelection.value = index
                }
            }
            toggleFeatureTable() 
            sketchViewModel.create("rectangle");
        } 
        
    });

    // add the clear selection button the view
    view.ui.add("clear-selection", "top-left");

    // add projectDiv's toggle button
    const toggleFTConfig = new Expand({
        view: view,
        expandTooltip: 'Feature Table',
        content: document.getElementById("projectionDiv"),
        expandIconClass: "esri-icon-table"
    });
    view.ui.add(toggleFTConfig, "top-left")

    /// Declare variables and function for csv export
    let resultFeatures = [];
    let recFeatures = [];
    let timeQueryFeatures = [];
    setupCSV();
    ////Add csv export button
    view.ui.add("btn-export", "top-left");

    // create feature table - set default layer to streets reconstruction
    const featureTable = new FeatureTable({
        view: view,
        layer: streets,
        hiddenFields: ['BoroCode', 'OBJECTID', 'FEMAFldz', 'FEMAFldT', 'HrcEvac', 'FMSID2'],
        tableTemplate: tableTemplate1,
        visibleElements: {
            // Autocast to VisibleElements
            menuItems: {
                clearSelection: true,
                refreshData: true,
                toggleColumns: true,
                selectedRecordsShowAllToggle: true,
                selectedRecordsShowSelectedToggle: true,
                zoomToSelection: true
            },
            selectionColumn: true
        },
        container: document.getElementById("tableDiv"),
        highlightOnRowSelectEnabled: false,
    });

    // re-filter by selection the feature table 
    view.watch('interacting', (interacting) => {
        // console.log(featureLayer.id)
        let fields_layer = []
        featureLayer.fields.forEach(field => {
            fields_layer.push(field.name)
        })
        // console.log('FIELDS', fields_layer)
        // console.log(featureTable)
        if(!interacting ){
            if(recFeatures.length) {
                featureTable.filterBySelection();
            } else {
                featureTable.clearSelection()
            }
        }
    })

    const checkbox = document.getElementById('checkboxId');
    const appContainer = document.getElementsByTagName('body');
    const tableContainer = document.getElementById('tableContainer');
    const tableDiv = document.getElementById('tableDiv');

    checkbox.onchange = () => {
        toggleFeatureTable();
    };

    function toggleFeatureTable() {
        // Check if the table is displayed, if so, toggle off. If not, display.
        if (!checkbox.checked) {
            tableContainer.style.display = 'none';
            // tableContainer.style.height = 0;
            // tableContainer.style.bottom = '6%';
        } else {
            const layerNameSelection = document.getElementById("layerNamesSelection")
            const layer = groupLayer.allLayers.getItemAt(layerNameSelection.value)
            handleFetureTableLayerChange(layer)
            featureTable.filterGeometry = view.extent

            tableContainer.style.display = 'inline'
            tableContainer.style.height = '30%';
            tableContainer.style.bottom = '0%';
        }
    }

    // create feature table selection 
    let layerNames = [];
    let featureLayer = streets;
    let LayerView;

    function handleFetureTableLayerChange(layer) {
        // console.log('layer', layer)
        featureTable.highlightIds.removeAll()

        featureTable.layer = featureLayer = layer;
        featureLayer.outFields = ['*'];

        if ((featureLayer == pedRamps) || (featureLayer == resurfacing) || (featureLayer == sidewalks)) {
            featureTable.tableTemplate = tableTemplate2;
        } else {
            featureTable.tableTemplate = tableTemplate1;
        };

        /// Select all features to export entire table by default   
        // let query = featureLayer.createQuery();
        // query.set({
        //     where: "1=1",
        //     returnGeometry: false
        // });

        // featureLayer.queryFeatures(query).then((featureSet) => {
        //     resultFeatures = featureSet.features;
        // })

        featureLayer.when(() => {
            view.whenLayerView(featureLayer).then(function (lv) {
                LayerView = lv
            });
        }).catch(errorCallback);

        if(featureTable.highlightIds?.length){
            featureTable.filterBySelection()
        }
        
    }

    // featureTable.watch('layer', (layer) => {
    //     handleFetureTableLayerChange(layer)
    // })

    // display feature table by selecting layer name from  drop down menu
    let select = document.getElementById("layerNamesSelection");
    select.addEventListener("change", () => {
        
        handleFetureTableLayerChange(groupLayer.allLayers.getItemAt(select.value))
        
    });
    // create dropdown menu containing on layer names
    // view.ui.add("projectionDiv", "top-right");
    view.when(() => {
        groupLayer.allLayers.forEach((layer, i) => {
            layerNames.push(layer.title);
            var opt = document.createElement("option");
            opt.value = i;
            opt.innerHTML = layer.title;
            select.appendChild(opt);
        });
    });



    let features = [];
    let selectedFeatures = [];

    featureTable.on('selection-change', (changes) => {
        changes.removed.forEach((item) => {
            const data = features.find((data) => {
                return data === item.objectId;
            });
            if (data) {
                selectedFeatures.splice(features.indexOf(data), 1);
                features.splice(features.indexOf(data), 1);
            }
        });

        changes.added.forEach((item) => {
            features.push(item.objectId);
            const itemFeature = item.feature

            if(itemFeature){
                selectedFeatures.push(itemFeature);
            }
        });

        // Disable the download btn if there is not feture selected
        if(selectedFeatures.length || recFeatures.length) {
            document.getElementById("btn-export").classList.remove("disabled")
        } else {
            document.getElementById("btn-export").classList.add("disabled")
        }

        // set excluded effect on the features that are not selected in the table
        featureTable.layer.featureEffect = {
            filter: {
              objectIds: features
            },
            excludedEffect: "blur(5px) opacity(95%)"
        };
    });

    
    document
        .getElementById("clear-selection")
        .addEventListener("click", () => {
            clearSelection()
            // featureTable.clearSelectionFilter()
            // featureTable.filterGeometry = view.extent
        });

    function clearSelection() {
        // featureTable.clearSelection();
        featureTable.highlightIds.removeAll()
        polygonGraphicsLayer.removeAll();
        selectedFeatures = [];
        recFeatures = [];
        rectGeometries = null
        features = [];

        featureTable.clearSelectionFilter()

        featureTable.layer.featureEffect = { //featureEffect can be assigned to each layer when initiated to avoid this piece of code
            filter: {
            objectIds: features
            },
            excludedEffect: "blur(5px) opacity(90%)"
        };

        

        filterFeatureTableByGeometryExtent()
    }
    

    // create a new sketch view model set its layer
    const sketchViewModel = new SketchViewModel({
        view: view,
        layer: polygonGraphicsLayer
    });

    let rectGeometries = null

    // Once user is done drawing a rectangle on the map
    // use the rectangle to select features on the map and table
    sketchViewModel.on("create", async (event) => {
        // if(LayerView.layer.id == "resurfacing") {
        //     slider.disabled = true
        // } else {
        //     slider.disabled = false
        // }

        document.getElementById("select-by-rectangle").classList.add("active")
        if (event.state === "complete") {
            // this polygon will be used to query features that intersect it
            const geometries = polygonGraphicsLayer.graphics.map(function (
                graphic
            ) {
                return graphic.geometry;
            });


            const queryGeometry = await geometryEngineAsync.union(
                geometries.toArray()
            );
                
            rectGeometries = queryGeometry;

            let trial
            LayerView.filter = timequery;
            await LayerView.queryFeatures().then(function(r) {
                // prints the array of result graphics to the console
                trial = r.features;
            });
            timeQueryFeatures = trial

            await selectFeatures(queryGeometry);
            document.getElementById("select-by-rectangle").classList.remove("active")
        }
    });

    sketchViewModel.on("update", async (event) => {
        document.getElementById("select-by-rectangle").classList.add("active")

        const event_type = event.toolEventInfo?.type.split('-')
        if ( event_type && event_type[1] === "stop") {
            featureTable.highlightIds.removeAll()
            selectedFeatures = [];
            recFeatures = [];
            features = [];
            // this polygon will be used to query features that intersect it
            const geometries = polygonGraphicsLayer.graphics.map(function (
                graphic
            ) {
                return graphic.geometry;
            });

            const queryGeometry = await geometryEngineAsync.union(
                geometries.toArray()
            );
                
            rectGeometries = queryGeometry;

            let trial
            LayerView.filter = timequery;
            await LayerView.queryFeatures().then(function(r) {
                trial = r.features;
            });
            timeQueryFeatures = trial

            await selectFeatures(queryGeometry);
        }
        document.getElementById("select-by-rectangle").classList.remove("active")
    })

    async function selectFeatures(geometry) {
        if (LayerView) {
            // create a query and set its geometry parameter to the
            // rectangle that was drawn on the view
            const query = {
                geometry: geometry,
                outFields: ["*"]
            };

            // query graphics from the csv layer view. Geometry set for the query
            // can be polygon for point features and only intersecting geometries are returned
            await LayerView
                .queryFeatures(query)
                .then(async (results) => {
                    const timeFilteredFeatures = timeQueryFeatures.length
                        ? timeQueryFilter(results.features)
                        : results.features
                    if (timeFilteredFeatures.length === 0) {
                        clearSelection();
                        const extentFeatures = await filterFeaturesByTimeExtent(view.extent)
                        featureTable.filterGeometry = null
                        featureTable.selectRows(extentFeatures)
                        featureTable.filterBySelection()
                        featureTable.highlightIds.removeAll()
                        featureTable.clearSelection()
                    } else {
                        // pass in the query results to the table by calling its selectRows method.
                        // This will trigger FeatureTable's selection-change event
                        // where we will be setting the feature effect on the csv layer view
                        
                        featureTable.filterGeometry = geometry;

                        featureTable.highlightIds.removeAll()
                        recFeatures = timeFilteredFeatures
                        featureTable.selectRows(recFeatures)
                        featureTable.filterBySelection()
                    }
                })
                .catch(errorCallback);
        }

    }

    function errorCallback(error) {
        console.log("error happened:", error.message);
    }

    async function currentExtent() {
        
        // featureTable.filterGeometry = null

        if(slider.values[0] == slider.min && slider.values[1] == slider.max){
            featureTable.filterGeometry = view.extent
        } 
        else if (timeQueryFeatures.length) {
            let trial
            LayerView.filter = timequery;
            await LayerView.queryFeatures().then(function(r) {
                // prints the array of result graphics to the console
                trial = r.features;
            });
            // timeQueryFeatures = trial
            let extentFeatures = await filterFeaturesByTimeExtent(view.extent);
            if (!extentFeatures?.length) { 
                clearSelection()
                featureTable.filterGeometry = null

            } else {
                featureTable.clearSelectionFilter()
                featureTable.selectRows(trial)
                featureTable.filterBySelection()
                featureTable.clearSelection()
            }
        } else {
            featureTable.clearSelectionFilter()
            featureTable.filterGeometry = view.extent
        }


    }

    reactiveUtils.when(
        () => view.stationary,
        () => {
          // Filter out and show only the visible features in the feature table.
          if(!rectGeometries){
            currentExtent()
          }

        },
        {
          initial: true
        }
    );

      reactiveUtils.watch(
        () => featureTable.highlightIds.length,
        (highlightIdsCount) => {
          // Iterate through the filters within the table.
          // If the active filter is "Show selection",
          // changes made to highlightIds (adding/removing)
          // are reflected.
      
          featureTable.viewModel.activeFilters.forEach((filter) => {
            if (filter.type === "selection") {
              selectionIdCount = filter.objectIds.length; // the filtered selection's id count
              // Check that the filter selection count is equal to the
              // highlightIds collection count. If not, update filter selection.
              if (selectionIdCount !== highlightIdsCount) {
                featureTable.filterBySelection();
              }
            }
          });
        }
      );


    // featureTable.tableCloseButton.addEventListener("click", function(e) {
    //   var gridMenuNode = registry.byId(table._gridMenu).domNode;
    //   var tableNode = registry.byId("tablePane").domNode;
    //   var borderContainer = registry.byId("borderContainer");
    //   var isOpening = e.target.classList.contains("toggleClosed");
    //   if (isOpening) {
    //     tableNode.style.height = tableNode.dataset.openHeight || "50%";
    //   } else {
    //     // Store the old height.
    //     tableNode.dataset.openHeight = tableNode.style.height || [tableNode.clientHeight, "px"].join("");
    //     // Set to "closed" height.
    //     tableNode.style.height = [gridMenuNode.clientHeight, "px"].join("");
    //   }
    //   borderContainer.resize();
    // });

    ///////////////////////// Export csv ////////////////////////////////////////////

    
    //Find districts member by id
    function matchDistric(key, value, datasetKey, nameKey = "name") {
        let res;
        if(!value){
            return value
        } else {
            const arr = value.split(",")
            res = arr.map(val => {
                const search = members[datasetKey].find(el => parseInt(el[key]) == val)
                return(search ? search[nameKey] : "Not Found")
            })
        }
        return res.join(', ')
    }

    function matchAssemblyDistric(value) {
        let res;
        if(!value){
            return value
        } else {
            const arr = value.split(",")
            res = arr.map(val => {
                const search = members["assemblyApiData"].find(el => el.id == val)
                return(search ? search.properties["Name"] : "Not Found")
            })
        }
        return res.join(', ')
    }

    function addMembers(feature) {
        const countDist = matchDistric("district", feature.attributes.CounDist, "CouncilApiData",)
        const congDist = matchDistric("district", feature.attributes.CongDist, "CongressApiData",)
        const stSenDist = matchDistric("districtCode", feature.attributes.StSenDist, "SenateApiData", "fullName")
        const assemDist = matchAssemblyDistric(feature.attributes.AssemDist)

        let newFeature = feature
        newFeature["attributes"] = {
                CounDistMember: countDist,
                CongDistMember: congDist, 
                AssemDistMember: assemDist,
                StSenDistMember: stSenDist,
                ...feature.attributes,
        }
        return newFeature.attributes;
    }

    function setupCSV() {
        const btn = document.getElementById("btn-export");

        //let select = document.getElementById("layerNamesSelection");                        
        btn.addEventListener("click", () => {
            const layerId = featureTable.layer.id
            //featureTable.layer = groupLayer.allLayers.getItemAt(select.value);
            featureLayer = select.value;
            
            if (recFeatures.length) {
                let attrs = recFeatures.map(a => addMembers(a));
                let headers = {};
                let entry = attrs[0];
                for (let key in entry) {
                    if (entry.hasOwnProperty(key)) {
                        headers[key] = key;
                    }
                }
                exportCSVFile(headers, attrs, "export_" + layerId, reorderedHeaders[featureLayer]);
            } else if (selectedFeatures.length) {
                let attrs = selectedFeatures.map(a => addMembers(a));
                let headers = {};
                let entry = attrs[0];
                for (let key in entry) {
                    if (entry.hasOwnProperty(key)) {
                        headers[key] = key;
                    }
                }
                exportCSVFile(headers, attrs, "export_" + layerId, reorderedHeaders[featureLayer]);
            } else if (resultFeatures.length) {
                let attrs = resultFeatures.map(a => addMembers(a));
                let headers = {};
                let entry = attrs[0];
                for (let key in entry) {
                    if (entry.hasOwnProperty(key)) {
                        headers[key] = key;
                    }
                }
                exportCSVFile(headers, attrs, "export_" + layerId, reorderedHeaders[featureLayer]);
            }
        });
    }

    function toExport(layerId, index) {
        //featureTable.layer = groupLayer.allLayers.getItemAt(select.value);
        featureLayer = select.value;

        if (resultFeatures.length) {
            let attrs = resultFeatures.map(a => addMembers(a));
            let headers = {};
            let entry = attrs[0];
            for (let key in entry) {
                if (entry.hasOwnProperty(key)) {
                    headers[key] = key;
                }
            }
            exportCSVFile(headers, attrs, "export_" + layerId, reorderedHeaders[index]);
        }
    }


    function convertToCSV(items, headers) {
        if (!items || items.length === 0 || !headers) {
            console.error('Invalid items or headers');
            return '';
        }

        // Convert items array to a 2D array with the desired order of columns
        const csvData = [Object.keys(headers)].concat(
            items.map(item => Object.keys(headers).map(header => {
                let el = item[header]
                if(typeof(el) === 'string'){
                    el = el.replace(",", '')
                }
                return el
            }))
        );

        // Convert 2D array to CSV string
        const BOM = "\uFEFF" // keep non-English characters
        const csv = BOM + csvData.map(row => row.join(',')).join('\r\n');

        return csv;
    }


    function exportCSVFile(headers, items, fileTitle, reorderedHeaders) {
        if (headers && reorderedHeaders && items && items.length > 0) {
            // Reorder headers
            headers = Object.fromEntries(reorderedHeaders.map(key => [key, headers[key]]));

            // Reorder items
            items = items.map(item => {
                return Object.fromEntries(reorderedHeaders.map(key => [key, item[key]]));
            });

            // Insert headers at the beginning of the items array
            items.unshift(headers);

            // Convert items array to CSV string
            const BOM = "\uFEFF" // keep non-English characters
            const csv = BOM + items.map(row => {
               return Object.values(row).map((value, i) => {
                    const header = Object.values(headers)
                    
                    if(typeof(value) != 'string' && header[i] && header[i].toLowerCase().includes('date')){
                        const date = new Date(value)
                        const month = date.getMonth(); // January returns 0
                        const day = date.getDate();
                        const year = date.getFullYear();
                        // console.log(month, day)
                        const new_value = `${month + 1}/${day}/${year}`
                        // console.log(new_value);
                        return `"${String(new_value).replace(/"/g, '""')}"`
                    } else {
                        return `"${String(value).replace(/"/g, '""')}"`
                    }
                    
                }).join('\t ,')
            }).join('\r\n');

            // Create and download the CSV file
            const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });

            if (navigator.msSaveBlob) {
                // IE 10+
                navigator.msSaveBlob(blob, fileTitle + '.csv');
            } else {
                const link = document.createElement('a');
                if (link.download !== undefined) {
                    // Browsers that support HTML5 download attribute
                    const url = URL.createObjectURL(blob);
                    link.setAttribute('href', url);
                    link.setAttribute('download', fileTitle + '.csv');
                    link.style.visibility = 'hidden';
                    document.body.appendChild(link);
                    link.click();
                    document.body.removeChild(link);
                }
            }
        }
    }





    function exportMembersCSVFile(headers, items, fileTitle) {
        // if (headers) {
        //     items.unshift(headers);
        // }

        // Convert Object to JSON
        var jsonObject = JSON.stringify(items);
        const csv = convertToCSV(items, headers);

        const exportedFilenmae = fileTitle + ".csv" || "export.csv";

        const blob = new Blob([csv], {
            type: "text/csv;charset=utf-8;"
        });
        if (navigator.msSaveBlob) {
            // IE 10+
            navigator.msSaveBlob(blob, exportedFilenmae);
        } else {
            const link = document.createElement("a");
            if (link.download !== undefined) {
                // feature detection
                // Browsers that support HTML5 download attribute
                const url = URL.createObjectURL(blob);
                link.setAttribute("href", url);
                link.setAttribute("download", exportedFilenmae);
                link.style.visibility = "hidden";
                document.body.appendChild(link);
                link.click();
                document.body.removeChild(link);
            }
        }
    };

    function sort_by_district_code() {
        return function (elem1, elem2) {
          if (elem1.District < elem2.District) {
            return -1;
          } else if (elem1.District > elem2.District) {
            return 1;
          } else {
            return 0;
          }
        };
    }
    
});